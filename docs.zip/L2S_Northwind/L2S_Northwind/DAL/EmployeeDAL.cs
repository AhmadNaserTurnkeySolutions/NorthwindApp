﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
namespace L2S_Northwind.DAL
{
    public class EmployeeDAL
    {
        NorthWindDataClassesDataContext dc;
        public EmployeeDAL() {
            dc = new NorthWindDataClassesDataContext();
        }

        public List<Employee> Ex1() 
        {
            var employees = from E in dc.Employees
                            select E;

            var e = from E in dc.Employees
                    let nbSuppliers =
                    (from O in E.Orders
                     from D in O.Order_Details
                     join P in dc.Products on D.ProductID equals P.ProductID
                     select P.SupplierID).Distinct().Count()
                    where nbSuppliers > 7
                    select E;

            IEnumerable<Employee> results = dc.ExecuteQuery<Employee>
            (@"SELECT * FROM Employees"
            );

            return results.ToList();
           // dc.Employees,
           // return employees.ToList<Employee>();
        }

    }
}
