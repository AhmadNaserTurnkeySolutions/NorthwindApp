﻿namespace L2S_Northwind
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.readToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tablesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shippersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeTerritoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.territoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerDemoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerDemographicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orderDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supplierProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.queriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeesByHireDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordersByIdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordersAndDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordersAndDetailsEntityRefToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordersAndDetailsByOrderIDEntityRefToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getTopFiveOrdersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleValuesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeByIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orderByIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orderValueByOrderIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.storedProceduresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesByYearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tenMostExpensiveProductsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertOrUpdateCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sQLQueriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex11ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex12ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex13ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex14ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex15ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex16ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex17ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex18ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex19ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex20ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex21ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex22ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex23ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex24ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex25ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ex26ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linqQueriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ex1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex3ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex4ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex5ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex6ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex7ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex8ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex9ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex10ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex11ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex12ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex13ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex14ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex15ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex16ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex17ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex18ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex19ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex20ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex21ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex22ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex23ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex24ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex25ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ex26ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.readToolStripMenuItem,
            this.writeToolStripMenuItem,
            this.sQLQueriesToolStripMenuItem,
            this.linqQueriesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(456, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // readToolStripMenuItem
            // 
            this.readToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tablesToolStripMenuItem,
            this.queriesToolStripMenuItem,
            this.storedProceduresToolStripMenuItem});
            this.readToolStripMenuItem.Name = "readToolStripMenuItem";
            this.readToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.readToolStripMenuItem.Text = "Read";
            // 
            // tablesToolStripMenuItem
            // 
            this.tablesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeesToolStripMenuItem,
            this.shippersToolStripMenuItem,
            this.ordersToolStripMenuItem,
            this.employeeTerritoryToolStripMenuItem,
            this.territoryToolStripMenuItem,
            this.regionToolStripMenuItem,
            this.customerToolStripMenuItem,
            this.customerDemoToolStripMenuItem,
            this.customerDemographicToolStripMenuItem,
            this.orderDetailsToolStripMenuItem,
            this.productToolStripMenuItem,
            this.supplierProductToolStripMenuItem,
            this.categoToolStripMenuItem});
            this.tablesToolStripMenuItem.Name = "tablesToolStripMenuItem";
            this.tablesToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.tablesToolStripMenuItem.Text = "Tables";
            // 
            // employeesToolStripMenuItem
            // 
            this.employeesToolStripMenuItem.Name = "employeesToolStripMenuItem";
            this.employeesToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.employeesToolStripMenuItem.Text = "Employees";
            this.employeesToolStripMenuItem.Click += new System.EventHandler(this.employeesToolStripMenuItem_Click);
            // 
            // shippersToolStripMenuItem
            // 
            this.shippersToolStripMenuItem.Name = "shippersToolStripMenuItem";
            this.shippersToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.shippersToolStripMenuItem.Text = "Shippers";
            this.shippersToolStripMenuItem.Click += new System.EventHandler(this.shippersToolStripMenuItem_Click);
            // 
            // ordersToolStripMenuItem
            // 
            this.ordersToolStripMenuItem.Name = "ordersToolStripMenuItem";
            this.ordersToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.ordersToolStripMenuItem.Text = "Orders";
            this.ordersToolStripMenuItem.Click += new System.EventHandler(this.ordersToolStripMenuItem_Click);
            // 
            // employeeTerritoryToolStripMenuItem
            // 
            this.employeeTerritoryToolStripMenuItem.Name = "employeeTerritoryToolStripMenuItem";
            this.employeeTerritoryToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.employeeTerritoryToolStripMenuItem.Text = "Employee Territory";
            this.employeeTerritoryToolStripMenuItem.Click += new System.EventHandler(this.employeeTerritoryToolStripMenuItem_Click);
            // 
            // territoryToolStripMenuItem
            // 
            this.territoryToolStripMenuItem.Name = "territoryToolStripMenuItem";
            this.territoryToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.territoryToolStripMenuItem.Text = "Territory";
            this.territoryToolStripMenuItem.Click += new System.EventHandler(this.territoryToolStripMenuItem_Click);
            // 
            // regionToolStripMenuItem
            // 
            this.regionToolStripMenuItem.Name = "regionToolStripMenuItem";
            this.regionToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.regionToolStripMenuItem.Text = "Region";
            this.regionToolStripMenuItem.Click += new System.EventHandler(this.regionToolStripMenuItem_Click);
            // 
            // customerToolStripMenuItem
            // 
            this.customerToolStripMenuItem.Name = "customerToolStripMenuItem";
            this.customerToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.customerToolStripMenuItem.Text = "Customer";
            this.customerToolStripMenuItem.Click += new System.EventHandler(this.customerToolStripMenuItem_Click);
            // 
            // customerDemoToolStripMenuItem
            // 
            this.customerDemoToolStripMenuItem.Name = "customerDemoToolStripMenuItem";
            this.customerDemoToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.customerDemoToolStripMenuItem.Text = "Customer Demo";
            this.customerDemoToolStripMenuItem.Click += new System.EventHandler(this.customerDemoToolStripMenuItem_Click);
            // 
            // customerDemographicToolStripMenuItem
            // 
            this.customerDemographicToolStripMenuItem.Name = "customerDemographicToolStripMenuItem";
            this.customerDemographicToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.customerDemographicToolStripMenuItem.Text = "Customer Demographic";
            this.customerDemographicToolStripMenuItem.Click += new System.EventHandler(this.customerDemographicToolStripMenuItem_Click);
            // 
            // orderDetailsToolStripMenuItem
            // 
            this.orderDetailsToolStripMenuItem.Name = "orderDetailsToolStripMenuItem";
            this.orderDetailsToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.orderDetailsToolStripMenuItem.Text = "Order Details";
            this.orderDetailsToolStripMenuItem.Click += new System.EventHandler(this.orderDetailsToolStripMenuItem_Click);
            // 
            // productToolStripMenuItem
            // 
            this.productToolStripMenuItem.Name = "productToolStripMenuItem";
            this.productToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.productToolStripMenuItem.Text = "Product";
            this.productToolStripMenuItem.Click += new System.EventHandler(this.productToolStripMenuItem_Click);
            // 
            // supplierProductToolStripMenuItem
            // 
            this.supplierProductToolStripMenuItem.Name = "supplierProductToolStripMenuItem";
            this.supplierProductToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.supplierProductToolStripMenuItem.Text = "Supplier";
            this.supplierProductToolStripMenuItem.Click += new System.EventHandler(this.supplierProductToolStripMenuItem_Click);
            // 
            // categoToolStripMenuItem
            // 
            this.categoToolStripMenuItem.Name = "categoToolStripMenuItem";
            this.categoToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.categoToolStripMenuItem.Text = "Category";
            this.categoToolStripMenuItem.Click += new System.EventHandler(this.categoToolStripMenuItem_Click);
            // 
            // queriesToolStripMenuItem
            // 
            this.queriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listsToolStripMenuItem,
            this.singleValuesToolStripMenuItem});
            this.queriesToolStripMenuItem.Name = "queriesToolStripMenuItem";
            this.queriesToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.queriesToolStripMenuItem.Text = "Queries";
            // 
            // listsToolStripMenuItem
            // 
            this.listsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeesByHireDateToolStripMenuItem,
            this.ordersByIdToolStripMenuItem,
            this.ordersAndDetailsToolStripMenuItem,
            this.ordersAndDetailsEntityRefToolStripMenuItem,
            this.ordersAndDetailsByOrderIDEntityRefToolStripMenuItem,
            this.getTopFiveOrdersToolStripMenuItem});
            this.listsToolStripMenuItem.Name = "listsToolStripMenuItem";
            this.listsToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.listsToolStripMenuItem.Text = "Lists";
            // 
            // employeesByHireDateToolStripMenuItem
            // 
            this.employeesByHireDateToolStripMenuItem.Name = "employeesByHireDateToolStripMenuItem";
            this.employeesByHireDateToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.employeesByHireDateToolStripMenuItem.Text = "Employees By Hire Date";
            this.employeesByHireDateToolStripMenuItem.Click += new System.EventHandler(this.employeesByHireDateToolStripMenuItem_Click);
            // 
            // ordersByIdToolStripMenuItem
            // 
            this.ordersByIdToolStripMenuItem.Name = "ordersByIdToolStripMenuItem";
            this.ordersByIdToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.ordersByIdToolStripMenuItem.Text = "Orders By ID";
            this.ordersByIdToolStripMenuItem.Click += new System.EventHandler(this.ordersByIdToolStripMenuItem_Click);
            // 
            // ordersAndDetailsToolStripMenuItem
            // 
            this.ordersAndDetailsToolStripMenuItem.Name = "ordersAndDetailsToolStripMenuItem";
            this.ordersAndDetailsToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.ordersAndDetailsToolStripMenuItem.Text = "Orders and Details";
            this.ordersAndDetailsToolStripMenuItem.Click += new System.EventHandler(this.ordersAndDetailsToolStripMenuItem_Click);
            // 
            // ordersAndDetailsEntityRefToolStripMenuItem
            // 
            this.ordersAndDetailsEntityRefToolStripMenuItem.Name = "ordersAndDetailsEntityRefToolStripMenuItem";
            this.ordersAndDetailsEntityRefToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.ordersAndDetailsEntityRefToolStripMenuItem.Text = "Orders and Details (Entity Set)";
            this.ordersAndDetailsEntityRefToolStripMenuItem.Click += new System.EventHandler(this.ordersAndDetailsEntityRefToolStripMenuItem_Click);
            // 
            // ordersAndDetailsByOrderIDEntityRefToolStripMenuItem
            // 
            this.ordersAndDetailsByOrderIDEntityRefToolStripMenuItem.Name = "ordersAndDetailsByOrderIDEntityRefToolStripMenuItem";
            this.ordersAndDetailsByOrderIDEntityRefToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.ordersAndDetailsByOrderIDEntityRefToolStripMenuItem.Text = "Orders and Details By Order ID (Entity Set)";
            this.ordersAndDetailsByOrderIDEntityRefToolStripMenuItem.Click += new System.EventHandler(this.ordersAndDetailsByOrderIDEntityRefToolStripMenuItem_Click);
            // 
            // getTopFiveOrdersToolStripMenuItem
            // 
            this.getTopFiveOrdersToolStripMenuItem.Name = "getTopFiveOrdersToolStripMenuItem";
            this.getTopFiveOrdersToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.getTopFiveOrdersToolStripMenuItem.Text = "Get Top Five Orders";
            this.getTopFiveOrdersToolStripMenuItem.Click += new System.EventHandler(this.getTopFiveOrdersToolStripMenuItem_Click);
            // 
            // singleValuesToolStripMenuItem
            // 
            this.singleValuesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeByIDToolStripMenuItem,
            this.orderByIDToolStripMenuItem,
            this.orderValueByOrderIDToolStripMenuItem});
            this.singleValuesToolStripMenuItem.Name = "singleValuesToolStripMenuItem";
            this.singleValuesToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.singleValuesToolStripMenuItem.Text = "Single Values";
            // 
            // employeeByIDToolStripMenuItem
            // 
            this.employeeByIDToolStripMenuItem.Name = "employeeByIDToolStripMenuItem";
            this.employeeByIDToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.employeeByIDToolStripMenuItem.Text = "Employee By ID";
            this.employeeByIDToolStripMenuItem.Click += new System.EventHandler(this.employeeByIDToolStripMenuItem_Click);
            // 
            // orderByIDToolStripMenuItem
            // 
            this.orderByIDToolStripMenuItem.Name = "orderByIDToolStripMenuItem";
            this.orderByIDToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.orderByIDToolStripMenuItem.Text = "Order By ID";
            this.orderByIDToolStripMenuItem.Click += new System.EventHandler(this.orderByIDToolStripMenuItem_Click);
            // 
            // orderValueByOrderIDToolStripMenuItem
            // 
            this.orderValueByOrderIDToolStripMenuItem.Name = "orderValueByOrderIDToolStripMenuItem";
            this.orderValueByOrderIDToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.orderValueByOrderIDToolStripMenuItem.Text = "Order Value By Order ID";
            this.orderValueByOrderIDToolStripMenuItem.Click += new System.EventHandler(this.orderValueByOrderIDToolStripMenuItem_Click);
            // 
            // storedProceduresToolStripMenuItem
            // 
            this.storedProceduresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salesByYearToolStripMenuItem,
            this.tenMostExpensiveProductsToolStripMenuItem});
            this.storedProceduresToolStripMenuItem.Name = "storedProceduresToolStripMenuItem";
            this.storedProceduresToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.storedProceduresToolStripMenuItem.Text = "Stored Procedures";
            // 
            // salesByYearToolStripMenuItem
            // 
            this.salesByYearToolStripMenuItem.Name = "salesByYearToolStripMenuItem";
            this.salesByYearToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.salesByYearToolStripMenuItem.Text = "Sales By Year";
            this.salesByYearToolStripMenuItem.Click += new System.EventHandler(this.salesByYearToolStripMenuItem_Click);
            // 
            // tenMostExpensiveProductsToolStripMenuItem
            // 
            this.tenMostExpensiveProductsToolStripMenuItem.Name = "tenMostExpensiveProductsToolStripMenuItem";
            this.tenMostExpensiveProductsToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.tenMostExpensiveProductsToolStripMenuItem.Text = "Ten Most Expensive Products";
            this.tenMostExpensiveProductsToolStripMenuItem.Click += new System.EventHandler(this.tenMostExpensiveProductsToolStripMenuItem_Click);
            // 
            // writeToolStripMenuItem
            // 
            this.writeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.insertOrUpdateCustomerToolStripMenuItem,
            this.deleteCustomerToolStripMenuItem});
            this.writeToolStripMenuItem.Name = "writeToolStripMenuItem";
            this.writeToolStripMenuItem.Size = new System.Drawing.Size(129, 20);
            this.writeToolStripMenuItem.Text = "Insert/Update/Delete";
            // 
            // insertOrUpdateCustomerToolStripMenuItem
            // 
            this.insertOrUpdateCustomerToolStripMenuItem.Name = "insertOrUpdateCustomerToolStripMenuItem";
            this.insertOrUpdateCustomerToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.insertOrUpdateCustomerToolStripMenuItem.Text = "Insert or Update Customer";
            this.insertOrUpdateCustomerToolStripMenuItem.Click += new System.EventHandler(this.insertOrUpdateCustomerToolStripMenuItem_Click);
            // 
            // deleteCustomerToolStripMenuItem
            // 
            this.deleteCustomerToolStripMenuItem.Name = "deleteCustomerToolStripMenuItem";
            this.deleteCustomerToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.deleteCustomerToolStripMenuItem.Text = "Delete Customer";
            this.deleteCustomerToolStripMenuItem.Click += new System.EventHandler(this.deleteCustomerToolStripMenuItem_Click);
            // 
            // sQLQueriesToolStripMenuItem
            // 
            this.sQLQueriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ex1ToolStripMenuItem,
            this.ex2ToolStripMenuItem,
            this.ex3ToolStripMenuItem,
            this.ex4ToolStripMenuItem,
            this.ex5ToolStripMenuItem,
            this.ex6ToolStripMenuItem,
            this.ex7ToolStripMenuItem,
            this.ex8ToolStripMenuItem,
            this.ex9ToolStripMenuItem,
            this.ex10ToolStripMenuItem,
            this.ex11ToolStripMenuItem,
            this.ex12ToolStripMenuItem,
            this.ex13ToolStripMenuItem,
            this.ex14ToolStripMenuItem,
            this.ex15ToolStripMenuItem,
            this.ex16ToolStripMenuItem,
            this.ex17ToolStripMenuItem,
            this.ex18ToolStripMenuItem,
            this.ex19ToolStripMenuItem,
            this.ex20ToolStripMenuItem,
            this.ex21ToolStripMenuItem,
            this.ex22ToolStripMenuItem,
            this.ex23ToolStripMenuItem,
            this.ex24ToolStripMenuItem,
            this.ex25ToolStripMenuItem,
            this.ex26ToolStripMenuItem});
            this.sQLQueriesToolStripMenuItem.Name = "sQLQueriesToolStripMenuItem";
            this.sQLQueriesToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.sQLQueriesToolStripMenuItem.Text = "SQL Queries";
            // 
            // ex1ToolStripMenuItem
            // 
            this.ex1ToolStripMenuItem.Name = "ex1ToolStripMenuItem";
            this.ex1ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex1ToolStripMenuItem.Text = "ex1";
            this.ex1ToolStripMenuItem.Click += new System.EventHandler(this.ex1ToolStripMenuItem_Click);
         
            // ex2ToolStripMenuItem
            // 
            this.ex2ToolStripMenuItem.Name = "ex2ToolStripMenuItem";
            this.ex2ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex2ToolStripMenuItem.Text = "ex2";
            // 
            // ex3ToolStripMenuItem
            // 
            this.ex3ToolStripMenuItem.Name = "ex3ToolStripMenuItem";
            this.ex3ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex3ToolStripMenuItem.Text = "ex3";
            // 
            // ex4ToolStripMenuItem
            // 
            this.ex4ToolStripMenuItem.Name = "ex4ToolStripMenuItem";
            this.ex4ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex4ToolStripMenuItem.Text = "ex4";
            // 
            // ex5ToolStripMenuItem
            // 
            this.ex5ToolStripMenuItem.Name = "ex5ToolStripMenuItem";
            this.ex5ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex5ToolStripMenuItem.Text = "ex5";
            // 
            // ex6ToolStripMenuItem
            // 
            this.ex6ToolStripMenuItem.Name = "ex6ToolStripMenuItem";
            this.ex6ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex6ToolStripMenuItem.Text = "ex6";
            // 
            // ex7ToolStripMenuItem
            // 
            this.ex7ToolStripMenuItem.Name = "ex7ToolStripMenuItem";
            this.ex7ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex7ToolStripMenuItem.Text = "ex7";
            // 
            // ex8ToolStripMenuItem
            // 
            this.ex8ToolStripMenuItem.Name = "ex8ToolStripMenuItem";
            this.ex8ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex8ToolStripMenuItem.Text = "ex8";
            // 
            // ex9ToolStripMenuItem
            // 
            this.ex9ToolStripMenuItem.Name = "ex9ToolStripMenuItem";
            this.ex9ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex9ToolStripMenuItem.Text = "ex9";
            // 
            // ex10ToolStripMenuItem
            // 
            this.ex10ToolStripMenuItem.Name = "ex10ToolStripMenuItem";
            this.ex10ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex10ToolStripMenuItem.Text = "ex10";
            // 
            // ex11ToolStripMenuItem
            // 
            this.ex11ToolStripMenuItem.Name = "ex11ToolStripMenuItem";
            this.ex11ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex11ToolStripMenuItem.Text = "ex11";
            // 
            // ex12ToolStripMenuItem
            // 
            this.ex12ToolStripMenuItem.Name = "ex12ToolStripMenuItem";
            this.ex12ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex12ToolStripMenuItem.Text = "ex12";
            // 
            // ex13ToolStripMenuItem
            // 
            this.ex13ToolStripMenuItem.Name = "ex13ToolStripMenuItem";
            this.ex13ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex13ToolStripMenuItem.Text = "ex13";
            // 
            // ex14ToolStripMenuItem
            // 
            this.ex14ToolStripMenuItem.Name = "ex14ToolStripMenuItem";
            this.ex14ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex14ToolStripMenuItem.Text = "ex14";
            // 
            // ex15ToolStripMenuItem
            // 
            this.ex15ToolStripMenuItem.Name = "ex15ToolStripMenuItem";
            this.ex15ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex15ToolStripMenuItem.Text = "ex15";
            // 
            // ex16ToolStripMenuItem
            // 
            this.ex16ToolStripMenuItem.Name = "ex16ToolStripMenuItem";
            this.ex16ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex16ToolStripMenuItem.Text = "ex16";
            // 
            // ex17ToolStripMenuItem
            // 
            this.ex17ToolStripMenuItem.Name = "ex17ToolStripMenuItem";
            this.ex17ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex17ToolStripMenuItem.Text = "ex17";
            // 
            // ex18ToolStripMenuItem
            // 
            this.ex18ToolStripMenuItem.Name = "ex18ToolStripMenuItem";
            this.ex18ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex18ToolStripMenuItem.Text = "ex18";
            // 
            // ex19ToolStripMenuItem
            // 
            this.ex19ToolStripMenuItem.Name = "ex19ToolStripMenuItem";
            this.ex19ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex19ToolStripMenuItem.Text = "ex19";
            // 
            // ex20ToolStripMenuItem
            // 
            this.ex20ToolStripMenuItem.Name = "ex20ToolStripMenuItem";
            this.ex20ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex20ToolStripMenuItem.Text = "ex20";
            // 
            // ex21ToolStripMenuItem
            // 
            this.ex21ToolStripMenuItem.Name = "ex21ToolStripMenuItem";
            this.ex21ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex21ToolStripMenuItem.Text = "ex21";
            // 
            // ex22ToolStripMenuItem
            // 
            this.ex22ToolStripMenuItem.Name = "ex22ToolStripMenuItem";
            this.ex22ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex22ToolStripMenuItem.Text = "ex22";
            // 
            // ex23ToolStripMenuItem
            // 
            this.ex23ToolStripMenuItem.Name = "ex23ToolStripMenuItem";
            this.ex23ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex23ToolStripMenuItem.Text = "ex23";
            // 
            // ex24ToolStripMenuItem
            // 
            this.ex24ToolStripMenuItem.Name = "ex24ToolStripMenuItem";
            this.ex24ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex24ToolStripMenuItem.Text = "ex24";
            // 
            // ex25ToolStripMenuItem
            // 
            this.ex25ToolStripMenuItem.Name = "ex25ToolStripMenuItem";
            this.ex25ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex25ToolStripMenuItem.Text = "ex25";
            // 
            // ex26ToolStripMenuItem
            // 
            this.ex26ToolStripMenuItem.Name = "ex26ToolStripMenuItem";
            this.ex26ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ex26ToolStripMenuItem.Text = "ex26";
            // 
            // linqQueriesToolStripMenuItem
            // 
            this.linqQueriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ex1ToolStripMenuItem1,
            this.ex2ToolStripMenuItem1,
            this.ex3ToolStripMenuItem1,
            this.ex4ToolStripMenuItem1,
            this.ex5ToolStripMenuItem1,
            this.ex6ToolStripMenuItem1,
            this.ex7ToolStripMenuItem1,
            this.ex8ToolStripMenuItem1,
            this.ex9ToolStripMenuItem1,
            this.ex10ToolStripMenuItem1,
            this.ex11ToolStripMenuItem1,
            this.ex12ToolStripMenuItem1,
            this.ex13ToolStripMenuItem1,
            this.ex14ToolStripMenuItem1,
            this.ex15ToolStripMenuItem1,
            this.ex16ToolStripMenuItem1,
            this.ex17ToolStripMenuItem1,
            this.ex18ToolStripMenuItem1,
            this.ex19ToolStripMenuItem1,
            this.ex20ToolStripMenuItem1,
            this.ex21ToolStripMenuItem1,
            this.ex22ToolStripMenuItem1,
            this.ex23ToolStripMenuItem1,
            this.ex24ToolStripMenuItem1,
            this.ex25ToolStripMenuItem1,
            this.ex26ToolStripMenuItem1});
            this.linqQueriesToolStripMenuItem.Name = "linqQueriesToolStripMenuItem";
            this.linqQueriesToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.linqQueriesToolStripMenuItem.Text = "Linq Queries";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 24);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(456, 293);
            this.dataGridView1.TabIndex = 1;
            // 
            // ex1ToolStripMenuItem1
            // 
            this.ex1ToolStripMenuItem1.Name = "ex1ToolStripMenuItem1";
            this.ex1ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex1ToolStripMenuItem1.Text = "ex1";
            // 
            // ex2ToolStripMenuItem1
            // 
            this.ex2ToolStripMenuItem1.Name = "ex2ToolStripMenuItem1";
            this.ex2ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex2ToolStripMenuItem1.Text = "ex2";
            // 
            // ex3ToolStripMenuItem1
            // 
            this.ex3ToolStripMenuItem1.Name = "ex3ToolStripMenuItem1";
            this.ex3ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex3ToolStripMenuItem1.Text = "ex3";
            // 
            // ex4ToolStripMenuItem1
            // 
            this.ex4ToolStripMenuItem1.Name = "ex4ToolStripMenuItem1";
            this.ex4ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex4ToolStripMenuItem1.Text = "ex4";
            // 
            // ex5ToolStripMenuItem1
            // 
            this.ex5ToolStripMenuItem1.Name = "ex5ToolStripMenuItem1";
            this.ex5ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex5ToolStripMenuItem1.Text = "ex5";
            // 
            // ex6ToolStripMenuItem1
            // 
            this.ex6ToolStripMenuItem1.Name = "ex6ToolStripMenuItem1";
            this.ex6ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex6ToolStripMenuItem1.Text = "ex6";
            // 
            // ex7ToolStripMenuItem1
            // 
            this.ex7ToolStripMenuItem1.Name = "ex7ToolStripMenuItem1";
            this.ex7ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex7ToolStripMenuItem1.Text = "ex7";
            // 
            // ex8ToolStripMenuItem1
            // 
            this.ex8ToolStripMenuItem1.Name = "ex8ToolStripMenuItem1";
            this.ex8ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex8ToolStripMenuItem1.Text = "ex8";
            // 
            // ex9ToolStripMenuItem1
            // 
            this.ex9ToolStripMenuItem1.Name = "ex9ToolStripMenuItem1";
            this.ex9ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex9ToolStripMenuItem1.Text = "ex9";
            // 
            // ex10ToolStripMenuItem1
            // 
            this.ex10ToolStripMenuItem1.Name = "ex10ToolStripMenuItem1";
            this.ex10ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex10ToolStripMenuItem1.Text = "ex10";
            // 
            // ex11ToolStripMenuItem1
            // 
            this.ex11ToolStripMenuItem1.Name = "ex11ToolStripMenuItem1";
            this.ex11ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex11ToolStripMenuItem1.Text = "ex11";
            // 
            // ex12ToolStripMenuItem1
            // 
            this.ex12ToolStripMenuItem1.Name = "ex12ToolStripMenuItem1";
            this.ex12ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex12ToolStripMenuItem1.Text = "ex12";
            // 
            // ex13ToolStripMenuItem1
            // 
            this.ex13ToolStripMenuItem1.Name = "ex13ToolStripMenuItem1";
            this.ex13ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex13ToolStripMenuItem1.Text = "ex13";
            // 
            // ex14ToolStripMenuItem1
            // 
            this.ex14ToolStripMenuItem1.Name = "ex14ToolStripMenuItem1";
            this.ex14ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex14ToolStripMenuItem1.Text = "ex14";
            // 
            // ex15ToolStripMenuItem1
            // 
            this.ex15ToolStripMenuItem1.Name = "ex15ToolStripMenuItem1";
            this.ex15ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex15ToolStripMenuItem1.Text = "ex15";
            // 
            // ex16ToolStripMenuItem1
            // 
            this.ex16ToolStripMenuItem1.Name = "ex16ToolStripMenuItem1";
            this.ex16ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex16ToolStripMenuItem1.Text = "ex16";
            // 
            // ex17ToolStripMenuItem1
            // 
            this.ex17ToolStripMenuItem1.Name = "ex17ToolStripMenuItem1";
            this.ex17ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex17ToolStripMenuItem1.Text = "ex17";
            // 
            // ex18ToolStripMenuItem1
            // 
            this.ex18ToolStripMenuItem1.Name = "ex18ToolStripMenuItem1";
            this.ex18ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex18ToolStripMenuItem1.Text = "ex18";
            // 
            // ex19ToolStripMenuItem1
            // 
            this.ex19ToolStripMenuItem1.Name = "ex19ToolStripMenuItem1";
            this.ex19ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex19ToolStripMenuItem1.Text = "ex19";
            // 
            // ex20ToolStripMenuItem1
            // 
            this.ex20ToolStripMenuItem1.Name = "ex20ToolStripMenuItem1";
            this.ex20ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex20ToolStripMenuItem1.Text = "ex20";
            // 
            // ex21ToolStripMenuItem1
            // 
            this.ex21ToolStripMenuItem1.Name = "ex21ToolStripMenuItem1";
            this.ex21ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex21ToolStripMenuItem1.Text = "ex21";
            // 
            // ex22ToolStripMenuItem1
            // 
            this.ex22ToolStripMenuItem1.Name = "ex22ToolStripMenuItem1";
            this.ex22ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex22ToolStripMenuItem1.Text = "ex22";
            // 
            // ex23ToolStripMenuItem1
            // 
            this.ex23ToolStripMenuItem1.Name = "ex23ToolStripMenuItem1";
            this.ex23ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex23ToolStripMenuItem1.Text = "ex23";
            // 
            // ex24ToolStripMenuItem1
            // 
            this.ex24ToolStripMenuItem1.Name = "ex24ToolStripMenuItem1";
            this.ex24ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex24ToolStripMenuItem1.Text = "ex24";
            // 
            // ex25ToolStripMenuItem1
            // 
            this.ex25ToolStripMenuItem1.Name = "ex25ToolStripMenuItem1";
            this.ex25ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex25ToolStripMenuItem1.Text = "ex25";
            // 
            // ex26ToolStripMenuItem1
            // 
            this.ex26ToolStripMenuItem1.Name = "ex26ToolStripMenuItem1";
            this.ex26ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.ex26ToolStripMenuItem1.Text = "ex26";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(456, 317);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LINQ To SQL";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem readToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tablesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem queriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem storedProceduresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem employeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shippersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeTerritoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem territoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerDemoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerDemographicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem orderDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem supplierProductToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem categoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem singleValuesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeByIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem orderByIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeesByHireDateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordersAndDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordersAndDetailsEntityRefToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordersAndDetailsByOrderIDEntityRefToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem orderValueByOrderIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getTopFiveOrdersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordersByIdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertOrUpdateCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesByYearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tenMostExpensiveProductsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sQLQueriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex9ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex10ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex11ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex12ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex13ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex14ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex15ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex16ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex17ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex18ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex19ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex20ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex21ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex22ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex23ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex24ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex25ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linqQueriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex26ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ex1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex2ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex3ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex4ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex5ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex6ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex7ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex8ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex9ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex10ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex11ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex12ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex13ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex14ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex15ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex16ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex17ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex18ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex19ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex20ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex21ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex22ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex23ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex24ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex25ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ex26ToolStripMenuItem1;
    }
}

